import React, { useState } from "react";
import Navbar from "./components/Navbar";
import LandingPage from "./components/LandingPage/LandingPage";
import SignUpModal from "./components/Authentication/SignUpModal"
import LoginModal from "./components/Authentication/LoginModal"
import Profile from "./components/profile/Profile";

const App = () => {
  const [isSignUpOpen, setSignUpOpen] = useState(false);
  const [isLoginOpen, setLoginOpen] = useState(false);
  const [isLoggedIn, setLoggedIn] = useState(false);
  const [showProfile, setShowProfile] = useState(false);

  const handleLoginSuccess = () => {
    setLoggedIn(true);
  };

  const toggleProfile = () => {
    setShowProfile(!showProfile);
  };

  return (
    <>
      <Navbar
        onSignUpClick={() => setSignUpOpen(true)}
        onLoginClick={() => setLoginOpen(true)}
        isLoggedIn={isLoggedIn}
        onProfileClick={toggleProfile}
      />
      {showProfile ? (
        <Profile onClose={toggleProfile} />
      ) : (
        <>
          <LandingPage/>
        </>
      )}
      <SignUpModal isOpen={isSignUpOpen} onClose={() => setSignUpOpen(false)} />
      <LoginModal
        isOpen={isLoginOpen}
        onClose={() => setLoginOpen(false)}
        onLoginSuccess={handleLoginSuccess}
      />
    </>
  );
};

export default App;
